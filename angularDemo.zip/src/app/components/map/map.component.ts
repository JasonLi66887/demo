
import { Component, OnInit } from '@angular/core';
declare var BMap: any;
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
  constructor() {}
  ngOnInit() {
    // const map = new BMap.Map('map');//创建地图实例
    // const point = new BMap.Point(116.404, 39.915);//创建点坐标
    // map.centerAndZoom(point, 15);//初始化地图，设置中心点坐标和地图级别
    // map.enableScrollWheelZoom(true);//开启鼠标滚轮缩放
    var map = new BMap.Map("map");
    map.enableScrollWheelZoom(true);
    // 创建地址解析器实例
    var myGeo = new BMap.Geocoder();


    // 将地址解析结果显示在地图上,并调整地图视野
    myGeo.getPoint("西宁市", function(point){
      if (point) {
        map.centerAndZoom(point, 5);
      }else{
        alert("您选择地址没有解析到结果!");
      }
    }, "北京市");
    myGeo.getPoint("天安门", function(point){
      if (point) {
        map.addOverlay(new BMap.Marker(point));
      }else{
        alert("您选择地址没有解析到结果!");
      }
    }, "北京市");
      myGeo.getPoint("东方明珠广播电视塔", function(point){
      if (point) {
        map.addOverlay(new BMap.Marker(point));
      }else{
        alert("您选择地址没有解析到结果!");
      }
    }, "上海市");
      myGeo.getPoint("广州塔", function(point){
      if (point) {
        map.addOverlay(new BMap.Marker(point));
      }else{
        alert("您选择地址没有解析到结果!");
      }
    }, "广州市");
  }
}
